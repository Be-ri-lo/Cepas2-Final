require "test_helper"

class EnologistTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
