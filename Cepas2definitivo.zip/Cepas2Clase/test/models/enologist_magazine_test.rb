require "test_helper"

class EnologistMagazineTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
