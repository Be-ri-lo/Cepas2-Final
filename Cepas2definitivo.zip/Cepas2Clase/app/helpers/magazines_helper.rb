module MagazinesHelper
end
